# scSpatio-FM: Multimodal Spatial Transcriptomics Imputation

This repository contains the end-to-end codebase for spatial transcriptomics analysis, combining Nextflow orchestration, R-based spatial deconvolution, and PyTorch Geometric/C++ for Foundation Model embedding and Graph Neural Network imputation.

## Directory Structure
* `data/`: Contains raw 10x Visium matrices and spatial images, and processed deconvolved `.h5ad` files.
* `results/`: Stores all QC reports, spatial 2D/3D visualizations, and GNN embeddings.
* `scripts/`: Modular scripts broken down by pipeline step (Orchestration -> Deconvolution -> LLM -> GNN -> C++).
