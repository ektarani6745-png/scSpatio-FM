#!/bin/bash
# Wrapper to trigger Nextflow
echo "Initializing scSpatio-FM Step 1: Downloading 10x Genomics Visium Data..."
cd "$(dirname "$0")"
nextflow run main.nf
echo "Process complete. Raw feature matrices and H&E images saved to ../../data/raw/"
